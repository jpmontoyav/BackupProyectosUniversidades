%Cladding modes
clear all
format short;
a1=2.625; %core radius
a2=62.5; %cladding radius
n1=1.458; %core index
n2=1.45; %cladding index
n3=1 ; %external index
Z0=570; %Grating Pitch in MICROMETERS!
A=1.55;%Wavelength in MICROMETERS!
k=2*pi./A; %Wavenumber
x=n2*k:-n3*k/1e+007:n3*k; % x is propagation constant range.
neff=x./k;% x=Beta propagation constant
V=(2*pi/A)*a1*sqrt(n1^2-n2^2);
d1=(neff./Z0)*1i;%Eq.(8)
d2=(neff.*Z0)*1i;%Eq.(9)
u1=sqrt((2*pi/A)^2.*(n1^2-neff.^2 ));%Eq. (12),j=l
u2=sqrt((2*pi/A)^2.*(n2^2-neff.^2));%Eq.(12), j =2
w3=sqrt((2*pi/A)^2.*(neff.^2-n3^2));%Eq.(13)
u21=1./u2.^2-1./u1.^2;%Eq.(10)
u32=1./w3.^2+1./u2.^2 ;%Eq.(11)
JJ1=(1/2).*(besselj(0,u1*a1)-besselj(2,u1*a1));
%diffrective of besselj J'(u1*a1)
KK1=-(1/2).*(besselk(0,w3*a2)+besselk(2,w3*a2));%K'(w3*a2)
J=JJ1./(u1.*besselj(1,u1*a1));%Eq.(14)
K=KK1./(w3.*besselk(1,w3*a2));%Eq.(15)
JJ21=(1/2).*(besselj(0,u2*a1)-besselj(2,u2*a1));
%diffrective of besselj'(u2*al)
JJ22=(1/2).*(besselj(0,u2*a2)-besselj(2,u2*a2));
%diffrective of besselj'(u2*a2)
NN21=(1/2).*(bessely(0,u2*a1)-bessely(2,u2*a1));
%diffrective of BESSELY'(u2*al)
NN22=(1/2).*(bessely(0,u2*a2)-bessely(2,u2*a2));
%diffrective of BESSELY'(u2*a2)
p1=besselj(1,u2*a2).*bessely(1,u2*a1) - besselj(1,u2*a1).*bessely(1,u2*a2);%Eq.(16)
q1=besselj(1,u2*a2).*NN21-JJ21.*bessely(1,u2*a2);%Eq.(17)
r1=JJ22.*bessely(1,u2*a1)-besselj(1,u2*a1).*NN22;%Eq.(18)
s1=JJ22.*NN21-JJ21.*NN22; %Eq.(19)

AA=u2.*(J.*K+(d1.*d2.*u21.*u32)./(n2^2*a1*a2)).*p1-K.*q1+J.*r1-(1./u2).*s1;%Eq.(6) nuEq.(6)merator
B=-u2.*((u32./(n2^2.*a2)).*J-(u21./(n1^2*a1)).*K).*p1+(u32./(n1^2*a2)).*q1+(u21./(n1^2*a1)).*r1;% denominator
G0=(1./d2).*AA./B; %Eq.(6)
G0imag=imag(G0);
C=u2.*((u32./a2).*J-(n3^2 .*u21./(n2^2*a1)).*K).*p1 -(u32/a2).*q1-(u21/a1).*r1;%Eq.(7) numerator
D=u2.*((n3^2/n2^2)*J.*K+d1.*d2.*u21.*u32/(n1^2*a1*a2)).*p1- (n3^2/n1^2 ).*K.*q1+J.*r1-(n2^2 ./(n1^2 .*u2)).*s1;%Eq.(7) denominator
G1=d1.*C./D;%Eq.(7)
G1imag=imag(G1);
y=G0imag-G1imag;
figure(1)
plot(x,y,'b');
figure(3)
plot(x,G0imag,'r');
figure(4)
plot(x,G1imag,'g');
%TODO: what do we gain from the dispersion relation plot? allowed cladding
%modes?
zeross=0;
index = 1;
for j=1:length(x)-1
if ((y(j)*y(j+1)<0)&&(abs(y(j)-y(j+1))<0.1))
zeross=zeross+1;
Bcl(index) = (x(j)+x(j+1))/2;
yval(index)= (y(j)+ y(j+1))/2;
index=index+1;
end
end


%Core Mode

for k = 1:length(Bcl)
sent = sprintf('Cladding modes:HE1,%d= %f, F:%0.4f',k,Bcl(k), yval(k));
disp(sent);
end
%writematrix(k,Bcl(k), yval(k),'claddingmodesHE1%d=%f_F%0.4f.csv'); %TODO:
%write as 3 functions appending

total_modes=zeross

%Calculate the field normalization constant Elv
x=Bcl;
k=2*pi./A;
neff=x/k;% x=B propgation constent
V=(2*pi/A)*a1*sqrt(n1^2-n2^2);
d1=(neff./Z0)*1i;%Eq.(8)
d2=(neff.*Z0)*1i;%Eq.(9)
u1=sqrt((2*pi/A)^2.*(n1^2-neff.^2 ));%Eq.(12),j=l
u2=sqrt((2*pi/A)^2.*(n2^2-neff.^2 ));%Eq.(12),j=2
w3=sqrt((2*pi/A)^2.*(neff.^2-n3^2 ));%Eq.(13)
u21=1./u2.^2-1./u1.^2;%Eq.(10)
u32=1./w3.^2+1./u2.^2;%Eq.(11)
JJ1=(1/2).*(besselj(0,u1*a1)-besselj(2,u1*a1));
%diffrective Of besselj J ’ (ul*al)
KK1=-(1/2).*(besselk(0,w3*a2)+besselk(2,w3*a2));
%K'(w3*a2)
J=JJ1./(u1.*besselj(1,u1*a1)) ;%Eq. (14)
K=KK1./(w3.*besselk(1,w3*a2));%Eq.(15)
JJ21=(1/2).*(besselj(0,u2*a1)-besselj(2,u2*a1));
%diffrective Of besselj'(u2*al)
JJ22=(1/2).*(besselj(0,u2*a2)-besselj(2,u2*a2));
%diffrective Of besselj'(u2*a2)
NN21=(1/2).*(bessely(0,u2*a1)-bessely(2, u2*a1));
%diffrective Of BESSELY'(u2*al)
NN22=(1/2).*(bessely(0,u2*a2)-bessely(2,u2*a2));
%diffrective Of BESSELY'(u2*a2)
p1=besselj(1,u2*a2).*bessely(1,u2*a1)-besselj(1,u2*a1).*bessely(1,u2*a2);%(16)
q1=besselj(1,u2*a2).*NN21-JJ21.*bessely(1,u2*a2);%Eq.(17)
r1=JJ22.*bessely(1,u2*a1)-besselj(1,u2*a1).*NN22;%Eq.(18)
s1=JJ22.*NN21-JJ21.*NN22; %Eq.(19)
AA=u2.*(J.*K+(d1.*d2.*u21.*u32)./(n2^2*a1*a2)).*p1-K.*q1+J.*r1-(1./u2).*s1;%Eq.(6) numerator
B=-u2.*((u32./(n2^2.*a2)).*J-(u21./(n1^2*a1)).*K).*p1+ (u32./(n1^2*a2)).*q1+(u21./(n1^2*a1)).*r1;
%Eq.(6) denominator
G0=(1./d2).*AA./B;%Eq.(6)
J011=besselj(0,u1*a1);
J111=besselj(1,u1*a1);
J211=besselj(2,u1*a1);
J311=besselj(3,u1*a1);
J021=besselj(0,u2*a1);
J022=besselj(0,u2*a2);
J121=besselj(1,u2*a1);
J122=besselj(1,u2*a2);
J221=besselj(2,u2*a1);
J222=besselj(2,u2*a2);
J321=besselj(3,u2*a1);
J322=besselj(3,u2*a2);
N021=bessely(0,u2*a1);
N022=bessely(0,u2*a2);
N121=bessely(1,u2*a1);
N122=bessely(1,u2*a2);
N221=bessely(2,u2*a1);
N222=bessely(2,u2*a2);
N321=bessely(3,u2*a1); 
N322=bessely(3,u2*a2);
OJ=a2^2.*(J222.^2-J122.*J322)-a1^2.*(J221.^2-J121.*J321);
ON=a2^2.*(N222.^2-N122.*N322)-a1^2.*(N221.^2-N121.*N321);
OJN=a2^2.*(J222.*N222-(1/2).*(J122.*N322+J322.*N122))- a1.^2.*(J221.*N221-0.5*(J121.*N321+J321.*N121));
OOJ=a2^2.*(J222.^2+J122.^2)-a1^2.*(J221.^2+J121.^2);
OON=a2^2.*(N222.^2+N122.^2)-a1^2.*(N221.^2+N121.^2);
OOJN=a2^2.*(J022.*N022+J122.*N122)- a1^2.*(J021.*N021+J121.*N121);
Q=OJ.*N121.^2+ON.*J121.^2-2*OJN.*J121.*N121;%Eq.(B4)
QQ=OOJ.*N121.^2+OON.*J121.^2-2.*OOJN.*J121.*N121;%Eq.(B5)
R = (1/4).*OJ.*(N221-N021).^2 + (1/4).*ON.*(J221-J021).^2 -(1/2).*OJN.* (N221-N021).*(J221-J021);%Eq.(B6)
RR = (1/4).*OOJ.*(N221-N021).^2 + (1/4).*OON.*(J221-J021).^2 -(1/2).*OOJN.*(N221-N021).*(J221-J021);%Eq.(B7)
S = (1/2).*OJ.*N121.*(N021-N221)+(1/2).*ON.*J121.*(J021-J221)- (1/2).*OJN.*(N121.*(J021-J221)+J121.*(N021-N221));%Eq. (B8)
SS=(1/2).*OOJ.*N121.*(N021-N221)+(1/2).*OON.*J121.*(J021-J221)-(1/2).*OOJN.*(N121.*(J021-J221)+J121.*(N021-N221));%Eq. (B9)
P11=(neff/Z0-((neff*Z0.*G0.^2)/(n1^2))+(1+(neff.^2)/(n1^2)).*imag(G0));%part of Eq.(B2)
P12=(neff/Z0-((neff*Z0.*G0.^2)/(n1^2))-(1+(neff.^2)/(n1^2)).*imag(G0));%part of Eq.(B2)
P1=((pi*a1^2.*u1.^2)/4).*(P11.*(J211.^2-J111.*J311)+P12.*(J011.^2+J111.^2));%Eq.(B2)
u21=1./u2.^2-1./u1.^2;%Eq.(10)
J=JJ1./(u1.*besselj(1,u1*a1)) ;
d1=(neff./Z0)*1i;%Eq.(8)
d2=(neff.*Z0)*1i;%Eq.(9)
F2=J-(u21.*d2.*G0)/ (n1^2*a1);
G2=G0.*J+u21.*d1/a1;
ne2=(1+neff.^2/n2^2);
P21=(neff/Z0.*F2.^2-(neff*Z0/n2^2 ).*G2.^2).*(Q+QQ);
%part of Eq.(B3)
P22=(1./(u2.^2)).*(neff/Z0-neff.*Z0.*n2^2.*G0.^2/n1^4).*(R+RR); %part of Eq.(B3)
P23=ne2.*F2.*imag(G2).*(Q-QQ)+ne2.*(n2^2 )./(n1^2 .*u2.^2).*imag(G0).*(R-RR);
%part of Eq.(B3)

P24=ne2.*(((n2^2.*imag(G0))./(n1^2.*u2)).*F2+1./u2.*imag(G2)).*(S-SS);%part of Eq.(B3)
P25=((2*neff./u2).*((Z0.*G0/(n1^2)).*G2-(1/Z0).*F2).*(S+SS));%part of Eq. (B3)
P2=((pi^3*a1^2.*u1.^4.*u2.^2.*J111.^2)/16).*(P21+P22+P23-P24+P25);%in Eq(B3) : (P21+P22+P23-P241+'P25);
K032=besselk(0,w3*a2);
K132=besselk(1,w3*a2);
K232=besselk(2,w3*a2);
K332=besselk(3,w3*a2);
ne3=1+neff.^2/n3^2;
F3=-F2.*p1+(1./u2).*q1;
G3=-(n3^2/n2^2).*(G2.*p1+(n2^2.*G0./(n1^2.*u2)).*q1);
P31=((neff*Z0/n3^2).*G3.^2-(neff/Z0).*F3.^2-ne3.*F3.*imag(G3)).*(K232.^2-K132.*K332);%part of Eq.(B16)
P32=(((neff*Z0/n3^2).*G3.^2-(neff/Z0).*F3.^2+ne3.*F3.*imag(G3)).*(K032.^2-K132.^2));%part of Eq.(B16)
P3=((pi^3.*a1^2.*a2^2.*u1.^4.*u2.^4.*J111.^2)./(16.*w3.^2 .*K132.^2)).*(P31+P32);%Eq.(B16)
Elv=sqrt(1./(P1+P2+P3));
figure (5);
plot(Bcl,Elv,'r');

%Core mode
A=1.55;%LPG peak wavelength
a1=2.625;%Core radia
a2=62.5;%Cladding radia
n1=1.458;%Core index
n2=1.45;%Cladding index
n3=1;%Souround index
k=2*pi./A;
B=n2*k: n2*k/1000000 : n1*k; % B range
neff=B/k;% x=B propgation constent
b=(neff.^2-n2^2 ) / (n1^2-n2^2 );%Normalized effective index
V=k*a1*sqrt(n1^2-n2^2);%V number
YL=V.*sqrt(1-b).*(besselj(1,V.*sqrt(1-b))./besselj(0,V.*sqrt(1-b)));%Eq.(1) Left side
YR=V.*sqrt(b).*(besselk(1,V.*sqrt(b))./besselk(0,V.*sqrt(b)));%Eq.(1) Right side
f=YL-YR;
%plot(B,f, 1g '),grid;
figure(5)
plot(B, YL , 'r ',B,YR,' k ' , B, f,' r ' ) ,grid;

zeross=0;
index = 1;
for j=1:length(B)-1
if (f(j)*f(j+1)<0)
zeross=zeross+1;
Bco(index) = (B(j)+B(j+1))/2;
fval(index)= (f(j)+ f (j+1))/2;
index=index+1;
end
end

for k = 1:length(Bco)
sent = sprintf('Core mode:HE1,%d= %f, F value: %0.4f',k,Bco(k), fval(k));
disp(sent);
end
%writematrix(k,Bcl(k), yval(k),'CoreModeHE1%d=%f_F%0.4f.csv');
total_modes=zeross
%Plot coupling constant Kcl-co
m = 1 :length(x) ;

A = 1.55;
k=2*pi./A;
Lambda=(1e+006*A./(Bco/k-Bcl/k));
neffco=Bco./k;
b=(neffco.^2-n2^2 )/ (n1^2-n2^2 );%Normalized effective index
D=(n1-n2)./n1;
K1 =((pi*b)./(Z0*n2*sqrt(1+2*b*D)))^0.5;
K2=(n1^2.*u1)./(u1.^2-(V^2*(1-b)/ (a1^2)));
K3 = (1+(d2.*G0)./(n1^2)) ;
K4=u1.*besselj(1, u1*a1) ;
K5=besselj(0,V*sqrt(1-b))./besselj(1,V*sqrt(1-b));
K6 = ((V*sqrt(1-b))/a1).*besselj(0, u1*a1) ;
Kclco=abs(k.*K1.*K2.*K3.*Elv.*(K4.*K5-K6));%Eq.(36)
figure(6)
plot(m,Kclco,'r'),grid;